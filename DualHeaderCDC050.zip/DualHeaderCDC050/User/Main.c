/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2021/08/08
 * Description        : Main program body.
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/

/*
 *@Note
 Example routine to emulate a simulate USB-CDC Device, USE USART1(PA9/PA10);
 Recommended to use UART2(PA2) as debug port, you can modify the debug port
 by modifying the macro definition in debug.h
 */

#include "UART.h"
#include "debug.h"
#include "usb_lib.h"
#include "usb_pwr.h"
#include "ch32v20x_usbfs_device.h"

#define DEF_USB_TX_MAXLENGTH   1024
volatile __attribute__ ((aligned(4))) uint8_t USB1_Tx_Buf[DEF_USB_TX_MAXLENGTH]; /* USB1 transmit data buffer */
volatile __attribute__ ((aligned(4))) uint8_t USB2_Tx_Buf[DEF_USB_TX_MAXLENGTH]; /* USB2 transmit data buffer */
volatile uint16_t USB1_Tx_Counter = 0;
volatile uint16_t USB2_Tx_Counter = 0;

bool USB1SendNull = FALSE;
bool USB2SendNull = FALSE;

bool USB1Configed = FALSE;
bool USB2Configed = FALSE;

uint8_t USB1Replay = 0xFF;
uint8_t USB2Replay = 0xFF;

extern volatile uint8_t USBD_Endp3_Busy;

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void) {
    uint8_t RPYMSG[4];

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);
    printf("USBD SimulateCDC Demo\r\n");

    RCC_Configuration();
    TIM2_Init();
    UART1_Init(1, DEF_UARTx_BAUDRATE, DEF_UARTx_STOPBIT, DEF_UARTx_PARITY);
    printf("USB1 Init\r\n");
    Set_USBConfig();
    USB1_Init();
    USB1_Interrupts_Config();

    printf("USB2 Init\r\n");
    /* USB20 device init */
    USBFS_RCC_Init();
    USBFS_Device_Init(ENABLE);

    printf("Enter Loop\r\n");
    while(1)
    {

        // If USB2 is connected, we will send data to USB2
        if (USBFS_DevEnumStatus == 1) {
            if ((USBFS_Endp_Busy[DEF_UEP3]==0)&&(USB1_Tx_Counter!=0)&&(USB1Replay==0xFF)) {
                printf("A[%d]\r\n",USB1_Tx_Counter);
                // Send data to USB2
                USBFS_Endp_DataUp( ENDP3, &USB1_Tx_Buf[0], USB1_Tx_Counter, DEF_UEP_CPY_LOAD);
                // If data length is 64, we should send a null package
                if (USB1_Tx_Counter==DEF_USBD_UEP0_SIZE) {
                    // Wait until USB2 is free
                    while (USBFS_Endp_Busy[DEF_UEP3]!=0) {
                    }
                    // Send a NULL package
                    USBFS_Endp_DataUp( ENDP3, &USB1_Tx_Buf[0], 0, DEF_UEP_CPY_LOAD);
                }
                USB1_Tx_Counter=0;
                // Enable USB1 Endpoint2
                SetEPRxValid( ENDP2);
            }
        } else {
            //If USB2 is NOT connected, data from USB1 would be dropped
            USB1_Tx_Counter=0;
            SetEPRxValid( ENDP2);
        }

        // If USB1 is connected, we will send data to USB1
        if (bDeviceState == CONFIGURED) {
            if ((USBD_Endp3_Busy==0)&&(USB2_Tx_Counter!=0)&&(USB2Replay==0xFF)) {
                    printf("B[%d]tU1\r\n",USB2_Tx_Counter);

                    // Send data to USB1
                    USBD_ENDPx_DataUp( ENDP3, &USB2_Tx_Buf[0], USB2_Tx_Counter);
                    // If data length is 64, we should send a null package
                    if (USB2_Tx_Counter==DEF_USBD_UEP0_SIZE) {
                        // Wait until USB1 is free
                        while (USBD_Endp3_Busy!=0) {
                        }
                        USBD_ENDPx_DataUp( ENDP3, &USB2_Tx_Buf[0], 0);
                    }
                    USB2_Tx_Counter=0;
                // Enable USB2 Endpoint2
                USBOTG_FS->UEP2_RX_CTRL &= ~USBFS_UEP_R_RES_MASK;
                USBOTG_FS->UEP2_RX_CTRL |= USBFS_UEP_R_RES_ACK;
            }
        } else {
            // For USB1 is not ready
            USB2_Tx_Counter=0;
            USBOTG_FS->UEP2_RX_CTRL &= ~USBFS_UEP_R_RES_MASK;
            USBOTG_FS->UEP2_RX_CTRL |= USBFS_UEP_R_RES_ACK;
        }

        if ((USB1Replay>0)&&(USB1Replay<5)) {
            // Reply USB1 Command
            if (USB1Replay==1) {
                RPYMSG[0]='U';
                RPYMSG[1]='S';
                RPYMSG[2]='B';
                RPYMSG[3]='1';
            }
            if (USB1Replay==2) {
                RPYMSG[0]='0';
                RPYMSG[1]='0';
                RPYMSG[2]='0';
                RPYMSG[3]='3';
            }
            if (USB1Replay==3) {
                RPYMSG[0]='1';
                RPYMSG[1]='2';
                RPYMSG[2]='3';
                RPYMSG[3]='4';
            }
            if (USB1Replay==4) {
                if (USB2Replay!=0xFF) {
                    RPYMSG[0]='R';
                    RPYMSG[1]='E';
                    RPYMSG[2]='D';
                    RPYMSG[3]='Y';
                } else {
                    RPYMSG[0]='N';
                    RPYMSG[1]='R';
                    RPYMSG[2]='D';
                    RPYMSG[3]='Y';
                }

            }
            USBD_ENDPx_DataUp( ENDP3, &RPYMSG, sizeof(RPYMSG)); // Send to USB1
            USB1Replay=0;
            SetEPRxValid( ENDP2);
        }

        if ((USB2Replay>0)&&(USB2Replay<5)) {
            // Reply USB2 Command
            if (USB2Replay==1) {
                RPYMSG[0]='U';
                RPYMSG[1]='S';
                RPYMSG[2]='B';
                RPYMSG[3]='2';
            }
            if (USB2Replay==2) {
                RPYMSG[0]='0';
                RPYMSG[1]='0';
                RPYMSG[2]='0';
                RPYMSG[3]='3';
            }
            if (USB2Replay==3) {
                RPYMSG[0]='1';
                RPYMSG[1]='2';
                RPYMSG[2]='3';
                RPYMSG[3]='4';
            }
            if (USB2Replay==4) {
                if (USB1Replay!=0xFF) {
                    RPYMSG[0]='R';
                    RPYMSG[1]='E';
                    RPYMSG[2]='D';
                    RPYMSG[3]='Y';
                } else {
                    RPYMSG[0]='N';
                    RPYMSG[1]='R';
                    RPYMSG[2]='D';
                    RPYMSG[3]='Y';
                }
            }
            USBFS_Endp_DataUp( ENDP3, &RPYMSG, sizeof(RPYMSG), DEF_UEP_CPY_LOAD); //Send to USB2
            USB2Replay=0;
            USBOTG_FS->UEP2_RX_CTRL &= ~USBFS_UEP_R_RES_MASK;
            USBOTG_FS->UEP2_RX_CTRL |= USBFS_UEP_R_RES_ACK;
        }

    }
}


/********************************** (C) COPYRIGHT *******************************
 * File Name          : usb_endp.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2021/08/08
 * Description        : Endpoint routines
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_mem.h"
#include "hw_config.h"
#include "usb_istr.h"
#include "usb_pwr.h"
#include "usb_prop.h"
#include "UART.h"
#include "ch32v20x_usbfs_device.h"

volatile uint8_t USBD_Endp3_Busy;
uint16_t USB_Rx_Cnt = 0;

/*********************************************************************
 * @fn      EP2_IN_Callback
 *
 * @brief  Endpoint 1 IN.
 *
 * @return  none
 */
void EP1_IN_Callback(void) {

}

/*********************************************************************
 * @fn      EP2_OUT_Callback
 *
 * @brief  Endpoint 2 OUT.
 *
 * @return  none
 */
void EP2_OUT_Callback(void) {

    //ZivDebug_Start
    uint32_t     Status;
    Status = _GetEPRxStatus(EP2_OUT);
    uint16_t USB1BufLen = GetEPRxCount( EP2_OUT & 0x7F);
    PMAToUserBufferCopy(&USB1_Tx_Buf[USB1_Tx_Counter], GetEPRxAddr( EP2_OUT & 0x7F),
            USB1BufLen);

    if (USB1Replay!=0xFF) {
        if ((USB1_Tx_Buf[0] == '?') && (USB1_Tx_Buf[1] == 'A')
                && (USB1_Tx_Buf[2] == 'C') && (USB1_Tx_Buf[3] == 'V')) {
            printf("RCV ACV CMD\r\n");
            USB1Replay = 0x01;
        }
        if ((USB1_Tx_Buf[0] == '?') && (USB1_Tx_Buf[1] == 'V')
                && (USB1_Tx_Buf[2] == 'E') && (USB1_Tx_Buf[3] == 'R')) {
            printf("RCV VER CMD\r\n");
            USB1Replay = 0x02;
        }
        if ((USB1_Tx_Buf[0] == '?') && (USB1_Tx_Buf[1] == 'S')
                && (USB1_Tx_Buf[2] == 'E') && (USB1_Tx_Buf[3] == 'R')) {
            printf("RCV SER CMD\r\n");
            USB1Replay = 0x03;
        }
        if ((USB1_Tx_Buf[0] == '?') && (USB1_Tx_Buf[1] == 'C')
                && (USB1_Tx_Buf[2] == 'F') && (USB1_Tx_Buf[3] == 'G')) {
            printf("RCV CFG CMD\r\n");
            USB1Replay = 0x04;
        }
    } else {
        //printf("EPS1[%d]\r\n",GetEPRxStatus(ENDP2));
        USB1_Tx_Counter=USB1BufLen;
        printf("EP2O[%d]\r\n",USB1_Tx_Counter);
    }

    /*
    if ((USBFS_DevEnumStatus == 1)&&(USBFS_Endp_Busy[DEF_UEP3]==0)) {
        printf("[%d]tU2\r\n",USB1BufLen);
        USBFS_Endp_DataUp( ENDP3, &USB1_Tx_Buf, USB1BufLen, DEF_UEP_DMA_LOAD); //Send Data to USB2
        SetEPRxValid( ENDP2);
    }
    */
    //ZivDebug_End

    /*
     PMAToUserBufferCopy( &USB1_Tx_Buf[ USB1BufLen ], GetEPRxAddr( EP2_OUT & 0x7F ), len );
     USB1BufLen=USB1BufLen+len;
     if( USB1BufLen > DEF_USB_TX_MAXLENGTH )
     {
     Uart.USB_Down_StopFlag = 0x01;
     }
     else
     {
     SetEPRxValid( ENDP2 );
     }

     /*
     PMAToUserBufferCopy( &UART1_Tx_Buf[ ( Uart.Tx_LoadNum * DEF_USB_FS_PACK_LEN ) ], GetEPRxAddr( EP2_OUT & 0x7F ), len );
     Uart.Tx_PackLen[ Uart.Tx_LoadNum ] = len;
     Uart.Tx_LoadNum++;
     if( Uart.Tx_LoadNum >= DEF_UARTx_TX_BUF_NUM_MAX )
     {
     Uart.Tx_LoadNum = 0x00;
     }
     Uart.Tx_RemainNum++;

     if( Uart.Tx_RemainNum >= ( DEF_UARTx_TX_BUF_NUM_MAX - 2 ) )
     {
     Uart.USB_Down_StopFlag = 0x01;
     }
     else
     {
     SetEPRxValid( ENDP2 );
     }
     */

}
/*********************************************************************
 * @fn      EP3_IN_Callback
 *
 * @brief  Endpoint 3 IN.
 *
 * @return  none
 */
void EP3_IN_Callback(void) {
    USBD_Endp3_Busy = 0;
    Uart.USB_Up_IngFlag = 0x00;
}

/*********************************************************************
 * @fn      USBD_ENDPx_DataUp
 *
 * @brief  USBD ENDPx DataUp Function
 * 
 * @param   endp - endpoint num.
 *          *pbuf - A pointer points to data.
 *          len - data length to transmit.
 * 
 * @return  data up status.
 */
uint8_t USBD_ENDPx_DataUp(uint8_t endp, uint8_t *pbuf, uint16_t len) {
    if (endp == ENDP3) {
        if (USBD_Endp3_Busy) {
            return USB_ERROR;
        }
        USB_SIL_Write( EP3_IN, pbuf, len);
        USBD_Endp3_Busy = 1;
        SetEPTxStatus( ENDP3, EP_TX_VALID);
    } else {
        return USB_ERROR;
    }
    return USB_SUCCESS;
}
